package com.mycompany.projngo;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ProjNGo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean executando = true;

        while (executando) {
            exibirMenu();
            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            switch (opcao) {
                case 1:
                    criarPasta(scanner);
                    break;
                case 2:
                    criarSubpasta(scanner);
                    break;
                case 3:
                    submeterArquivo(scanner);
                    break;
                case 4:
                    calcularTamanhoPasta(scanner);
                    break;
                case 5:
                    excluirArquivosEPastas(scanner);
                    break;
                case 6:
                    mostrarPastasExistentes();
                    break;
                case 7:
                    executando = false;
                    System.out.println("Encerrando o sistema...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("===== Sistema de Gerenciamento de Arquivos =====");
        System.out.println("1. Criar pasta");
        System.out.println("2. Criar subpasta");
        System.out.println("3. Submeter arquivo");
        System.out.println("4. Calcular tamanho da pasta");
        System.out.println("5. Excluir arquivos e pastas");
        System.out.println("6. Mostrar pastas existentes");
        System.out.println("7. Sair");
        System.out.println("Digite o número da opção desejada:");
    }

    private static void criarPasta(Scanner scanner) {
        System.out.println("Digite o nome da pasta:");
        String nomePasta = scanner.nextLine();

        File novaPasta = new File(nomePasta);
        if (novaPasta.mkdir()) {
            System.out.println("Pasta criada com sucesso!");
        } else {
            System.out.println("Não foi possível criar a pasta.");
        }
    }

private static void criarSubpasta(Scanner scanner) {
    System.out.println("Digite o caminho da pasta pai:");
    String caminhoPai = scanner.nextLine();

    File pastaPai = new File(caminhoPai);
    if (!pastaPai.exists() || !pastaPai.isDirectory()) {
        System.out.println("Caminho pai inválido. Certifique-se de que a pasta existe.");
        return;
    }

    System.out.println("Digite o nome da subpasta:");
    String nomeSubpasta = scanner.nextLine();

    File subpasta = new File(caminhoPai, nomeSubpasta);
    if (subpasta.exists()) {
        System.out.println("A subpasta já existe. Escolha outro nome.");
        return;
    }

    if (subpasta.mkdir()) {
        System.out.println("Subpasta criada com sucesso!");
    } else {
        System.out.println("Falha ao criar a subpasta.");
    }
}


    private static void submeterArquivo(Scanner scanner) {
        System.out.println("Digite o caminho da pasta onde deseja submeter o arquivo:");
        String caminhoPasta = scanner.nextLine();

        System.out.println("Digite o nome do arquivo:");
        String nomeArquivo = scanner.nextLine();

        System.out.println("Digite o tipo de arquivo:");
        String tipoArquivo = scanner.nextLine();

        System.out.println("Digite o tamanho do arquivo em bytes:");
        long tamanhoArquivo = scanner.nextLong();



        System.out.println("Arquivo submetido com sucesso!");
    }

    private static void calcularTamanhoPasta(Scanner scanner) {
        System.out.println("Digite o nome da pasta:");
        String nomePasta = scanner.nextLine();

        File pasta = new File(nomePasta);
        long tamanhoTotal = calcularTamanhoRecursivo(pasta);

        System.out.println("Tamanho total da pasta '" + nomePasta + "': " + tamanhoTotal + " bytes");
    }

    private static long calcularTamanhoRecursivo(File file) {
        long tamanhoTotal = 0;

        if (file.isFile()) {
            tamanhoTotal += file.length();
        } else if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    tamanhoTotal += calcularTamanhoRecursivo(subFile);
                }
            }
        }

        return tamanhoTotal;
    }

    private static void excluirArquivosEPastas(Scanner scanner) {
        System.out.println("Digite o caminho do arquivo ou pasta a ser excluído:");
        String caminho = scanner.nextLine();

        boolean sucesso = excluirRecursivo(new File(caminho));

        if (sucesso) {
            System.out.println("Exclusão concluída com sucesso!");
        } else {
            System.out.println("Não foi possível excluir o arquivo ou pasta.");
        }
    }

    private static boolean excluirRecursivo(File file) {
        boolean sucesso = true;

        if (file.isFile()) {
            sucesso = file.delete();
        } else if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File subFile : files) {
                    sucesso = excluirRecursivo(subFile) && sucesso;
                }
            }

            sucesso = file.delete() && sucesso;
        }

        return sucesso;
    }

 private static void mostrarPastasExistentes() {
    File pastaAtual = new File(".");
    mostrarPastasSubpastas(pastaAtual, "");
}

private static void mostrarPastasSubpastas(File pasta, String prefixo) {
    File[] pastas = pasta.listFiles(File::isDirectory);

    if (pastas != null && pastas.length > 0) {
        for (File subpasta : pastas) {
            if (!ignorarPasta(subpasta)) {
                System.out.println(prefixo + subpasta.getName());
                mostrarPastasSubpastas(subpasta, prefixo + subpasta.getName() + "/");
            }
        }
    }
}

private static boolean ignorarPasta(File pasta) {
    String nomePasta = pasta.getName();
    List<String> pastasIgnoradas = Arrays.asList("target", "src");
    return pastasIgnoradas.contains(nomePasta);
}


}
